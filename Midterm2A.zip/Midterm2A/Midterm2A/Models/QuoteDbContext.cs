﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm2A.Models
{
    public class QuoteDbContext : DbContext
    {
        public QuoteDbContext (DbContextOptions<QuoteDbContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
    => options.UseSqlite("DataSource=QuoteDb.sqlite");
        public DbSet<Quote> Quotes { get; set; }
    }
    
}
